echo "nohup /home/aria2/aria2c --conf-path=/home/aria2/aria2.conf -D >> /var/log/aria2.log &" >> /etc/rc.local
