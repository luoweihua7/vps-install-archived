#!/usr/bin/env bash

ARIA2_CONF="/usr/local/etc/aria2/aria2.conf"
RPC_ADDRESS="http://localhost:6800/jsonrpc"

randstr() {
  index=0
  strRandomPass=""
  for i in {a..z}; do
    arr[index]=$i
    index=$(expr ${index} + 1)
  done
  for i in {A..Z}; do
    arr[index]=$i
    index=$(expr ${index} + 1)
  done
  for i in {0..9}; do
    arr[index]=$i
    index=$(expr ${index} + 1)
  done
  for i in {1..16}; do strRandomPass="$strRandomPass${arr[$RANDOM % $index]}"; done
  echo $strRandomPass
}

date_time() {
  # date +"%m/%d %H:%M:%S"

  # 保持跟ARIA2输出格式一致
  date -d today +"%Y-%m-%d %T.%6N"
}

log_info() {
  # tracker更新过程记录到日志，方便定位
  echo -e "$(date_time) [NOTICE] [update-tracker.sh] ${1}" >>/tmp/aria2.log
}

check_interval() {
  # 更新频率，短时间内不更新
  echo ""
  NOW=$(($(date +%s%N) / 1000000))
  LAST_UPDATE=$(cat /tmp/aria2_tracker.lastupdate)

  if [ -z $LAST_UPDATE ]; then
    LAST_UPDATE="0"
  fi

  INTERVAL=$(expr $NOW - $LAST_UPDATE)

  echo $NOW >/tmp/aria2_tracker.lastupdate
  log_info "Last update tracker from now is ${INTERVAL}ms"

  # 5 * 60 = 300秒间隔
  if [ $INTERVAL -gt 300000 ]; then
    return 0
  else
    return 1
  fi
}

get_trackers() {
  logger "Fetching BT trackers ..."
  DOWNLOADER="curl -fsSL --connect-timeout 3 --max-time 3 --retry 2"
  TRACKER=$(
    ${DOWNLOADER} https://trackerslist.com/all_aria2.txt ||
      ${DOWNLOADER} https://cdn.jsdelivr.net/gh/XIU2/TrackersListCollection@master/all_aria2.txt ||
      ${DOWNLOADER} https://trackers.p3terx.com/all_aria2.txt
  )
  [[ -z "${TRACKER}" ]] && {
    log_info "Unable to get trackers, network failure or invalid links." && exit 1
  }
}

add_trackers() {
  if [ ! -f ${ARIA2_CONF} ]; then
    log_info "'${ARIA2_CONF}' does not exist. abort!"
    exit 1
  else
    # 更新到conf配置文件
    log_info "Update aria2 config file: ${ARIA2_CONF}"
    if [ -z $(grep "bt-tracker=" ${ARIA2_CONF}) ]; then
      # 这里要求 aria2.conf 文件最后有一个空行，不然会有问题
      echo "bt-tracker=" >>${ARIA2_CONF}
    fi
    sed -i "s@^\(bt-tracker=\).*@\1${TRACKER}@" ${ARIA2_CONF} && log_info "Aria2 config file updated!"

    # 通过接口更新当前服务
    REQID=$(randstr)
    if [ -z $(grep "rpc-secret=" ${ARIA2_CONF}) ]; then
      RPC_PAYLOAD='{"jsonrpc":"2.0","method":"aria2.changeGlobalOption","id":"'${REQID}'","params":[{"bt-tracker":"'${TRACKER}'"}]}'
    else
      # 非得在secret配置后面加注释的话，就不管了
      RPC_SECRET=$(grep "rpc-secret=" ${ARIA2_CONF} | awk -F "=" '{print $2}')
      RPC_PAYLOAD='{"jsonrpc":"2.0","method":"aria2.changeGlobalOption","id":"'${REQID}'","params":["token:'${RPC_SECRET}'",{"bt-tracker":"'${TRACKER}'"}]}'
    fi
    UPDATE_RESULT=$(curl "${RPC_ADDRESS}" -fsSd "${RPC_PAYLOAD}" || curl "https://${RPC_ADDRESS}" -kfsSd "${RPC_PAYLOAD}")
    log_info "Update aria2 service, result is ${UPDATE_RESULT}"
    log_info "BT trackers updated!"
  fi
}

if check_interval; then
  # 大于间隔时间，则执行tracker更新
  get_trackers
  add_trackers
else
  log_info "The interval is too short, skip the update"
fi
