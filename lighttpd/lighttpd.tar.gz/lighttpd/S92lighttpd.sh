#!/bin/bash
pid=`ps | grep lighttpd.conf | grep -v grep | awk '{print $1}'`

startLighttpd() {
    if [ ! -d "/tmp/lighttpd" ]; then
        mkdir /tmp/lighttpd
    fi
    /usr/sbin/lighttpd -f /koolshare/lighttpd/lighttpd.conf
    echo "Lighttpd runing"
}

stopLighttpd(){
    kill $pid
    echo "Lighttpd stopped"
}

case $1 in
start)
    if [ ! -n $pid ];then
        echo "Lighttpd is runing"
    else
      startLighttpd
    fi
    ;;
stop | kill )
    if [ ! -n $pid ];then
        stopLighttpd
    else
        echo "Lighttpd is not runing"
    fi
    ;;
restart)
    stopLighttpd
    startLighttpd
    ;;
*)
    echo "Usage: $0 (start|stop|restart)"
    exit 1
    ;;
esac